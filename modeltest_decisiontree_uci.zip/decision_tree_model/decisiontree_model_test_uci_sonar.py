import pandas as pd, numpy as np
import matplotlib; matplotlib.use('Agg')
import matplotlib.pyplot as plt
from sklearn.model_selection import train_test_split
from sklearn.tree import DecisionTreeClassifier
from sklearn.metrics import accuracy_score, recall_score

df = pd.read_csv('/mnt/user-data/uploads/uci_sonar_clean.csv')
X = df.iloc[:, :-2]; y = df.iloc[:, -2]

RS = 42                      # fixed, same as the notebook
depths = [3, 4, 5, 6, 7]

Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, random_state=RS, stratify=y)
rows = []
for d in depths:
    clf = DecisionTreeClassifier(random_state=RS, max_depth=d).fit(Xtr, ytr)
    pred = clf.predict(Xte)
    rows.append({'random_state': RS, 'max_depth': d,
                 'overall_accuracy': round(accuracy_score(yte, pred), 4),
                 'rock_accuracy': round(recall_score(yte, pred, pos_label='R'), 4),
                 'mine_accuracy': round(recall_score(yte, pred, pos_label='M'), 4),
                 'train_accuracy': round(accuracy_score(ytr, clf.predict(Xtr)), 4)})
res = pd.DataFrame(rows)
print(res.to_string(index=False))
res.to_csv('accuracy_by_depth.csv', index=False)

fig, ax = plt.subplots(figsize=(8, 5.5))
ax.plot(res.max_depth, res.overall_accuracy, 'k-s', lw=3, label='Overall (test)')
ax.plot(res.max_depth, res.rock_accuracy, 'o--', label='Rock')
ax.plot(res.max_depth, res.mine_accuracy, '^--', label='Mine')
ax.plot(res.max_depth, res.train_accuracy, ':', color='gray', marker='.', label='Overall (train)')
for x_, y_ in zip(res.max_depth, res.overall_accuracy): ax.annotate(f'{y_:.3f}', (x_, y_), textcoords='offset points', xytext=(0, 8), ha='center')
ax.set(xlabel='max_depth', ylabel='Accuracy', title=f'Decision tree accuracy vs max_depth (random_state={RS})')
ax.set_xticks(depths); ax.grid(alpha=.3); ax.legend()
plt.tight_layout(); plt.savefig('accuracy_vs_depth.png', dpi=150)
